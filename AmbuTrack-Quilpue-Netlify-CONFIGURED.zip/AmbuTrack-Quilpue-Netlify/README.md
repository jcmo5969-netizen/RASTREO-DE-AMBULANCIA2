# AmbuTrack Quilpué – Deploy en Netlify

Este proyecto crea:
- **Tablero web** (`index.html`) con Google Maps, marcadores en tiempo real y tarjetas con QR por ambulancia.
- **Página móvil del conductor** (`driver.html`) a la que se accede escaneando el QR. Comparte ubicación en tiempo real y permite ingresar un destino para calcular ETA.
- **Tiempo real** con **Supabase** (suscripciones Postgres) – no requiere servidor propio.

## Requisitos
1. **Google Cloud**: activar *Maps JavaScript API*, *Directions API* y *Places API*. Crear API Key y restringir por dominio.
2. **Supabase**: crear proyecto y habilitar Realtime.

## SQL Supabase
```sql
create table if not exists public.ambulance_status (
  ambulance_id text primary key,
  lat double precision,
  lng double precision,
  heading double precision,
  speed double precision,
  updated_at timestamptz default now(),
  dest_address text,
  dest_lat double precision,
  dest_lng double precision,
  eta_seconds integer
);
alter table public.ambulance_status replica identity full;

alter table public.ambulance_status enable row level security;

create policy "public select" on public.ambulance_status
  for select using (true);

create policy "public upsert" on public.ambulance_status
  for insert with check (true);

create policy "public update" on public.ambulance_status
  for update using (true) with check (true);
```
En *Database > Replication > Publications*, agrega `public.ambulance_status` a `supabase_realtime`.

## Configurar llaves
En `index.html` y `driver.html` reemplaza:
- `YOUR_GOOGLE_MAPS_API_KEY`
- `window.SUPABASE_URL`
- `window.SUPABASE_ANON_KEY`

## Deploy en Netlify
1. Crea sitio → **Deploy manually** y sube esta carpeta o el ZIP.
2. Abre la URL del sitio (HTTPS).
3. Escanea el QR desde el celular del conductor → autoriza ubicación.
4. Escribe la dirección y presiona **Calcular ETA**.

## Notas
- Para producción agrega autenticación por ambulancia y restringe más las políticas RLS.
